import pandas as pd
import matplotlib.pyplot as plt
import os

# Path to the CSV file
csvPath = os.path.expanduser('~/turtlebot4_ws/logs/robotLog.csv')

# Load CSV
df = pd.read_csv(csvPath)

# Plot robot position based on CSV
plt.figure()
plt.plot(df['X'], df['Y'], marker='o', linestyle='-')
plt.title('Robot Path (X vs Y)')
plt.xlabel('X Position (m)')
plt.ylabel('Y Position (m)')
plt.grid(True)
plt.axis('equal')
plt.show()
